# GraficasApp

Recuerden que para que funcione la gráfica, deben de levantar también el json-server con este archivo json
https://gist.github.com/Klerith/1a7dae845948649a667aacf46a6971f5
